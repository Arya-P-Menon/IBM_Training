package com.ibm.test;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.ibm.dao.ProductDao;
import com.ibm.entity.Product;

public class TestProduct {
	
	private static ProductDao dao;

	@BeforeAll
	public static void setup() {
		dao = new ProductDao();
	}

	@Test
	public void testAdd() {

		Product p = new Product();
		p.setpName("Phone");

		assertNotEquals(0, dao.addProduct(p));
	}

	@Test
	public void testFind() {
		Product p = dao.findProduct(17);
		assertNotNull(p);
		System.out.println(p);
	}
	
	@Test
	public void testUpdate() {
		Product p = new Product();
		p.setpId(17);
		p.setpName("Mobile");
		
		assertNotNull(dao.updateProduct(p));
		
		System.out.println(p);
	}
	
	@Test
	public void testRemoveDept() {
		assertTrue(dao.removeProduct(17));
	}

}
