import java.io.FileReader;
import java.util.Properties;

public class PropsDemo {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		FileReader reader = new FileReader("src\\person.txt");
		
		Properties p = new Properties();	//properties are implementation of map
		p.load(reader);
		
		System.out.println(p.getProperty("name"));
		System.out.println(p.getProperty("age"));
		System.out.println(p.getProperty("city"));

	}

}
