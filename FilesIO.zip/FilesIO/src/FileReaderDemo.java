import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {
	
	public static void main(String[] args) {
		
		String path = "C:\\Users\\ibmjavafsdmr05\\Desktop\\IBM_Sample\\Hello.txt";
		BufferedReader reader = null;
		String line = null;
	
		try {
			FileReader fr = new FileReader(path);	//opening file stream
			reader = new BufferedReader(fr);	//wrapping buffer around it	// buffer reads from memory thus its faster
												// reads multiple bytes together
			 
			while(true) {
				line=reader.readLine();	//reads a line from buffer
				if(line==null)	//EOF
					break;
				System.out.println(line);
			
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				if(reader != null)
					reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
