import java.io.Serializable;

// objects are binary data
public class Person implements Comparable<Person>, Serializable{//serializable is a blank interface(marker interfaces)

	private static final long serialVersionUID = 1L;//hover on person and click add serial id

	
	private String name;
	private transient int age;//transient are non-serialisable attributes// data will not be send 
	
	public Person() {
		// TODO Auto-generated constructor stub
	}

	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	


		@Override
	public int compareTo(Person p) {
		// TODO Auto-generated method stub
		return this.getAge() - p.getAge();
	}
		

	
}
