import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FastCopy {
	
public static void main(String[] args) {
		
		FileInputStream inFile = null;
		FileOutputStream outFile = null;
		BufferedInputStream inBuffer = null;
		BufferedOutputStream outBuffer = null;
		
		try {
			inFile = new FileInputStream("D:\\Dummy\\python.exe");
			outFile = new FileOutputStream("D:\\Dummy\\p2.exe");
			inBuffer = new BufferedInputStream(inFile,1024*16);	// creating 16KB input buffer
			outBuffer = new BufferedOutputStream(outFile,1024*16);
			
			System.out.println("Copying File...");
			int ch=0;
			long msg1 = System.currentTimeMillis();
			while(true) {
				ch = inBuffer.read();
				if(ch==-1) break;
				outBuffer.write(ch);
			}
			long msg2 = System.currentTimeMillis();
			System.out.println("File copied Successfully..."+ (msg2-msg1) + "ms");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				inBuffer.close();
				outBuffer.close();
				inFile.close();
				outFile.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
	}

}
