import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BinaryReadDemo {	//Reader returns chars
	
	public static void main(String[] args) {
		
		String path = "C:\\Users\\ibmjavafsdmr05\\Desktop\\IBM_Sample\\Hello.txt";
		FileInputStream istream = null;
		try {//to add try catch block, select the codes right click surround with try catch->initialise istream to null->put stream.close in finally and surround close in try catch
			
			istream = new FileInputStream(path);	// reads one byte at a time from file thus its slower than bufferreader

			
//			int ch = 0;	
//			while(true) {
//				ch = istream.read();	// reading a byte from stream
//				if(ch==-1) 	//	when end of file reached
//					break;	//exit loop
//				System.out.print((char)ch);
//			}
			
			
			byte[] content = new byte[istream.available()];	// returns count of available bytes in stream
			istream.read(content);		//reading bytes from stream into array//if printed result refers to the number of bytes read
			System.out.println(new String(content));	// converting byte array to string

			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		finally {
			try {
				istream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
