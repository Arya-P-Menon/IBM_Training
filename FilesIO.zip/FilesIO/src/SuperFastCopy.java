import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class SuperFastCopy {

public static void main(String[] args) {
		
		FileInputStream inFile = null;
		FileOutputStream outFile = null;
		FileChannel inChannel = null;
		FileChannel outChannel = null;

		
		try {
			inFile = new FileInputStream("D:\\Dummy\\python.exe");
			outFile = new FileOutputStream("D:\\Dummy\\p2.exe");
			inChannel = inFile.getChannel();
			outChannel = outFile.getChannel();
			
			ByteBuffer buffer = ByteBuffer.allocate(1024*16);//creating 16kb common buffer//created in jvm memory
			
			System.out.println("Copying File...");
			long msg1 = System.currentTimeMillis();
			while(true) {
				int count = inChannel.read(buffer);
				if(count==-1) break;
				buffer.flip();	//placing cursor back to the start of the buffer
				outChannel.write(buffer);
				buffer.clear();
			}
			long msg2 = System.currentTimeMillis();
			System.out.println("File copied Successfully in "+(msg2-msg1)+"ms");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				inFile.close();
				outFile.close();
				inChannel.close();
				outChannel.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
}
