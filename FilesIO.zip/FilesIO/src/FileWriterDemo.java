import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String path ="src\\TempFile.txt";//right click on project -> refresh
		BufferedWriter writer = null;
		
		try {
			//writer = new BufferedWriter(new FileWriter(path));
			writer = new BufferedWriter(new FileWriter(path,true));// to append to file
			writer.write("Arya");
			writer.newLine();
			writer.write("Arya P");
			writer.newLine();
			writer.write("Arya P Menon");
			writer.newLine();
			
			System.out.println("File writing completed");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
		
		if(writer != null)
			try {
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
