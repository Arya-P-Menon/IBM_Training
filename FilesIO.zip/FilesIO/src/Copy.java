import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Copy {
	public static void main(String[] args) {
		
		FileInputStream inFile = null;
		FileOutputStream outFile = null;

		
		try {
			inFile = new FileInputStream("D:\\Dummy\\python.exe");
			outFile = new FileOutputStream("D:\\Dummy\\p2.exe");

			
			System.out.println("Copying File...");
			int ch=0;
			long msg1 = System.currentTimeMillis();
			while(true) {
				ch = inFile.read();
				if(ch==-1) break;
				outFile.write(ch);
			}
			long msg2 = System.currentTimeMillis();
			System.out.println("File copied Successfully in "+(msg2-msg1)+"ms");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				inFile.close();
				outFile.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
