import java.io.File;
import java.io.IOException;
import java.util.Date;

public class FileDemo {
	
	public static void main(String[] args) throws IOException {
		
		File file = new File("C:\\Users\\ibmjavafsdmr05\\Desktop\\IBM_Sample\\Hello.txt");
	//	File file = new File("C:\\Users\\ibmjavafsdmr05\\Desktop\\IBM_Sample");
		
		if(file.exists()) {
			System.out.println(file.getName());
			System.out.println(file.getCanonicalPath());
			System.out.println(file.getAbsolutePath());
			
			if(file.isFile()) {
				System.out.println(file.canRead());
				System.out.println(file.canWrite());
				System.out.println(file.canExecute());//have permission to execute or not
				
				Date date = new Date(file.lastModified());
				System.out.println(date);
				
				System.out.println(file.lastModified());
				System.out.println(file.length());
			}
			else {
				System.out.println("Content of the directory");
				String [] contents = file.list();
				for(String s : contents)
					System.out.println(s);
			}
			
		}
		else {
			System.out.println("File does not exists");
		}
		
	}
}
