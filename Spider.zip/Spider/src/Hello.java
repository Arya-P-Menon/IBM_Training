

@FunctionalInterface
public interface Hello {
	String sayHello();
	
	default void sayHola() {
		System.out.println("Hola Monde");
	}
	
	static void saySomething() {
		System.out.println("Something");
	}
}

class HelloDemo{
	public static void main(String[] args) {
		
		Hello h = () -> "Hello World";
		System.out.println(h.sayHello());
		
		Hello h1 = () -> {
			String msg =  "Hello Again";
			return msg;
		};
		System.out.println(h1.sayHello());
		h1.sayHola();
		
		Hello.saySomething();
	}
}