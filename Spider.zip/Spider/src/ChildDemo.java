
public class ChildDemo<T, A> extends NewDemo<T> {
	
	private A temp;

	public ChildDemo(T data, A temp) {
		super(data);
		this.temp = temp;
	}

	public A getTemp() {
		return temp;
	}

	public void setTemp(A temp) {
		this.temp = temp;
	}
	
	
	public static void main(String[] args) {
		
		ChildDemo<String, Integer> cd = new ChildDemo<String,Integer>("Arya", 1000);
		System.out.println(cd.getData()+ " " + cd.getTemp());
		cd.setTemp(3000);
		cd.setData("Vishnu");
		System.out.println(cd.getData()+" " +cd.getTemp());
	}

}
