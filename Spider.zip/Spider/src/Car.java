
public class Car {
	
	private String model;
	private String[] features;
	
	
	public Car(String model, String...features) { //var args //normal function -->public Car(String model, String[] features)
		this.model = model;
		this.features = features;
	}
	
	public void specs() {
		System.out.println("Features of " + model);
		for(String f : features)
			System.out.println(" > " + f);
	}
	
	public static void main(String[] args) {
		
		//String[] falto = {"Keyless", "Power Steering" , "AC"}; Car alto = new Car("Suzuki",falto);//normal case
		Car alto = new Car("Suzuki Alto", "Keyless", "Power Steering" , "AC");
		
		//String[] fhect = {"ABS", " Climate Control" , "Cruise", "Air Bags", "Keyless Starting"};
		Car hector = new Car("MG Hector", "ABS", " Climate Control" , "Cruise", "Air Bags", "Keyless Starting");
		
		alto.specs();
		hector.specs();
		
		
	}
	

}
