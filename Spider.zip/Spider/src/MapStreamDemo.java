import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MapStreamDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, String> people = new HashMap<String, String>();
		people.put("Arya", "OTP");
		people.put("Arya P", "PKD");
		people.put("Arya P Menon", "KL");
		
		people.values().stream().forEach(System.out::println);
		
		System.out.println("***************************");
		
		List<String> cities = people.values().stream().map(c->c.toUpperCase()).sorted().collect(Collectors.toList());
		cities.forEach(System.out::println);
		
		System.out.println("***************************");

		Map<String,List<String>> contacts = new HashMap<String, List<String>>();
		contacts.put("Fred",Arrays.asList("123-446-789","987-654-321"));
		contacts.put("Cat",Arrays.asList("123-765-789","987-000-321"));
		contacts.put("Mark",Arrays.asList("123-333-789","987-777-321"));
		
		contacts.values().stream().forEach(System.out::println);
		
		System.out.println("***************************");

		contacts.values().stream().flatMap(Collection::stream).forEach(System.out::println);

	}

}
