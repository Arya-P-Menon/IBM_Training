
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream; 

public class FileStream {
	
	public static void main(String[] args) throws IOException {
		
		Stream<String> band = Files.lines(Paths.get("src\\band.txt"));
//		List<String> baja = band.collect(Collectors.toList());//collect is a terminal operation
//		List<String> baja = band.sorted().collect(Collectors.toList());
//		List<String> baja = band.filter(s->s.contains("S")).collect(Collectors.toList());
		
//		baja.forEach(System.out::println);
		
//		band.sorted().filter(s->s.length()>10).forEach(System.out::println);
		
		Stream<String> data = Files.lines(Paths.get("src\\data.txt"));
		
//		System.out.println((int)data.filter(r->r.length()>5).count());
		
//		data.map(r-> r.split(",")).filter(ar -> ar.length == 3)
//			.forEach(System.out::println);//prints as object value
		
//		data.map(r-> r.split(",")).filter(ar -> ar.length == 3)
//			.forEach(ar-> System.out.println(ar[0] + " "+ ar[1]+ " "+ ar[2]));//to print values as such
		
//		data.map(r-> r.split(",")).filter(ar -> ar.length == 3)//for each row split//split returns array//for array length==3
//			.filter(ar->Integer.parseInt(ar[1])>15)
//			.forEach(ar-> System.out.println(ar[0] + " "+ ar[1]+ " "+ ar[2]));//to print values as such
		
		Map<String, Double> map = data.map(r->r.split(",")).filter(ar->ar.length==3)
								.collect(Collectors.toMap(ar->ar[0], ar->
								Double.parseDouble(ar[1])+Double.parseDouble(ar[2])));
		
		for(String k : map.keySet())
			System.out.println(k+ " = "+ map.get(k));
	}

}
