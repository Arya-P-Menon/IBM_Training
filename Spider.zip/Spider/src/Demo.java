
public class Demo {
	
	private Object data;

	public Demo(Object data) {
		this.data = data;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
	public static void main(String[] args) {
		
		Demo d1 = new Demo("Hello");
		System.out.println(d1.getData());
		d1.setData(1000);
		System.out.println(d1.getData());
		
		Demo d2 = new Demo(1000);
		System.out.println(d2.getData());
		d2.setData("Hi");
		
		//System.out.println(d1.getData()+d2.getData()); // not possible as objects cannot be added
		d2.setData(new Car("AR","mm"));
		System.out.println(d2.getData());
	}
	

}
