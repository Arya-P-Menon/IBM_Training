
public class NewDemo<T> {
	
	private T data;

	public NewDemo(T data) {
		super();
		this.data = data;
	}
	
	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		NewDemo<String> d1 = new NewDemo<String>("Arya");
		System.out.println(d1.getData());
		
		NewDemo<Integer> d2 = new NewDemo<Integer>(1000);
		NewDemo<Integer> d3 = new NewDemo<Integer>(100);
		System.out.println(d2.getData() + d3.getData());
		

	}

}
