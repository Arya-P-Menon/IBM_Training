import java.util.ArrayList;
import java.util.List;

public class ParallelStreamDemo {
	
	public static void process(int i) {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> numbers = new ArrayList<Integer>();
		for(int n=0; n<=1000; n++) {
			numbers.add(n);
		}
		
		long startTime = System.currentTimeMillis();
		numbers.stream().forEach(ParallelStreamDemo::process);//process in sequence hence more time
		//numbers.stream().forEach(System.out::println);
		long endTime = System.currentTimeMillis();
		System.out.println("Time taken by sequential stream : " + (endTime-startTime));
		
		startTime = System.currentTimeMillis();
		numbers.stream().forEach(ParallelStreamDemo::process);//process in multiple threads hence less time
		//numbers.parallelStream().forEach(System.out::println);
		endTime = System.currentTimeMillis();
		System.out.println("Time taken by parallel stream : " + (endTime-startTime));
		

	}

}
