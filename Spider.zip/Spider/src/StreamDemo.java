import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamDemo {
	
	public static void print(Object obj) { // if integer instead of object then function works only for integer collection
		System.out.println(obj);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer[] arr = {3,2,5,7,9,2};
		List<Integer> numbers = Arrays.asList(arr);
		numbers.forEach(System.out::println);	// short hand introduced in java 8 :: is the method reference
		
		System.out.println("***********************");
		numbers.forEach(StreamDemo::print);
		
		System.out.println("Printing Distinct Numbers");
		numbers.stream().distinct().forEach(System.out::println); // stream and distinct are intermediate operations and for each is terminal operation
		//after terminal operation no other operations are possible. return type of terminal operations will be void
		//collections have to be converted into streams to perform some operations
		System.out.println("***********************");
		
		Stream<Integer> str1 = numbers.stream().distinct();//storing resultant stream into another stream
		str1.forEach(System.out :: println);
	//	System.out.println(str1.count());// creates error as after terminal operation is closed. foreach is a terminal operation

		System.out.println("***********************");
		
		Stream<Integer> str2 = numbers.stream().filter(n->n>=5); //filter is a predicate function, returns true values
		str2.forEach(System.out::println);
		
		System.out.println("***********************");
		
		numbers.stream().limit(3).forEach(System.out::println);
		
		System.out.println("***********************");
		
		numbers.stream().distinct().sorted().forEach(System.out::println);
		
		System.out.println("***********************");
		
		//Printing sum of streams
		System.out.println(numbers.stream().mapToInt(i->i).sum());
		System.out.println(numbers.stream().reduce(0, (a,b)->a+b));//optimised
		System.out.println(numbers.stream().reduce(0, Integer::sum));//optimised - go with it
		System.out.println(numbers.stream().mapToInt(Integer::intValue).sum());
		System.out.println(numbers.stream().collect(Collectors.summingInt(Integer::intValue)));
		
		System.out.println("***********************");
		
		System.out.println(IntStream.range(1, 99).count());//excludes 99
		IntStream.range(1, 10).skip(5).forEach(System.out::println);//skips first 5 elements,excludes 10
		System.out.println(IntStream.range(1, 10).sum());//excludes 10
		
		IntSummaryStatistics summary = IntStream.of(7,2,19,88,73,4,10).summaryStatistics();//to get summay like count, min,avg,max,sum
		System.out.println(summary);
		
				
		}

}
