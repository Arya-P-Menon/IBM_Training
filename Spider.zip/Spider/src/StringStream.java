
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StringStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] star = {"Cherry","Orange","Mango","Apple","Banana","Grapes","Grapes"};
		List<String> input = Arrays.asList(star);
		input.forEach(System.out::println);
		
		System.out.println("***********************");
		
		input.stream().sorted().forEach(System.out::println);
		
		System.out.println("***********************");
		
		input.stream().map(str->str.toUpperCase()).forEach(System.out::println);
		
		System.out.println("***********************");
		
		input.stream().findFirst().ifPresent(System.out::println);
		
		System.out.println("***********************");
		
		input.stream().filter(str->str.startsWith("P")).forEach(System.out::println);
		
		System.out.println("***********************");
		
		input.stream().filter(str->str.contains("ple")).forEach(System.out::println);
		
		System.out.println("***********************");
		
		System.out.println(input.stream().count());
		
		System.out.println("***********************");
		
		input.stream().distinct().sorted().forEach(System.out::println);
		
		System.out.println("***********************");
		
		Stream.of("Arya","Arya P","Arya P Menon").sorted().forEach(System.out::println);
		
		System.out.println(Arrays.stream(star).map(s->s.toLowerCase()).filter(s->s.contains("p")).count());
		
		System.out.println("***********************");

	}

}
