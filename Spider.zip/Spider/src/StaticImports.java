import static java.lang.Math.*;
import static java.lang.System.out;

public class StaticImports {

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		
		System.out.println("Hello World");
		
	//	System.out.println(Math.PI); // without importing statically
	//	System.out.println(Math.random()*100); //without importing statically
		
		//with static importing
		out.println(PI);
		out.println(random()*100);

	}

}
