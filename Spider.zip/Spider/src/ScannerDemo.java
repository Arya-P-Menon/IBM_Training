import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner console = new Scanner(System.in);
		
		
		System.out.print("Enter name : ");
		String name = console.next();
		
		String namePattern = "[A-Z][a-z]{3,}";
		System.out.println("Your Name is " + (name.matches(namePattern)?"Valid":"Invalid"));
		
		System.out.print("Enter Mobile No. : ");
		String mobile = console.next();
		
		String mobilePattern = "[7-9][0-9]{9}";
		System.out.println("Mobile No. is " + (mobile.matches(mobilePattern)?"Valid":"Invalid"));
		
		System.out.print("Enter Age : ");
		String age = console.next();
		
		String agePattern = "[0-9][1-9]";
		System.out.println("Age. is " + (age.matches(agePattern)?"Valid":"Invalid"));
		
		console.close();
		
	}

}
