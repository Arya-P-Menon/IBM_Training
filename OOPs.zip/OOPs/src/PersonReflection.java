import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class PersonReflection {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		Person p = new Person("Polo",11);
		
		//Class pc = p.getClass();
		Class pc = Class.forName("Person");
		System.out.println(pc.getName());
		
		Constructor[] constructor = pc.getConstructors();
		System.out.println("List of Constructors");
		for(Constructor c : constructor)
			System.out.println(c);
			
		Method[] methods = pc.getMethods();
		System.out.println("List of Methods");
		for(Method m : methods)
			System.out.println(m);
		
		Method[] decMethods = pc.getDeclaredMethods();
		System.out.println("List of  Declared Methods");
		for(Method m : decMethods)
			System.out.println(m);
		
		Field[] decFields = pc.getDeclaredFields();
		System.out.println("List of Declared Fields");
		for(Field f : decFields)
			System.out.println(f);
	}

}
