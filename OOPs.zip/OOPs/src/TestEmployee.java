

import com.ibm.emp.Employee;
import com.ibm.emp.Executive;
import com.ibm.emp.Manager;

public class TestEmployee {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1 = new Employee();
		e1.paySlip();

		Employee e2 = new Employee("Arya", 400000);
		e2.paySlip();
		System.out.println(e2.getSalary());
		
		Manager m1 = new Manager("Vishnu",9000000,45000);
		m1.paySlip();
		System.out.println(m1.getSalary());
		
		Executive ex1 = new Executive("Appu",45678,9876);
		ex1.paySlip();
		System.out.println(ex1.getSalary());
		
		showSalary(m1);
		showSalary(ex1);
	}
	
	//Ploymorphic Method
	private static void showSalary(Employee emp) {
		
		if(emp instanceof Manager)	//Runtime Type Identification
			System.out.println("Manager Salary : " + emp.getSalary());
		else
			System.out.println("Executive Salary : " + emp.getSalary());
	}
	
	
/*  Method Overloading
	private static void showSalary(Executive ex) { //Method Overloading
		// TODO Auto-generated method stub
		
		System.out.println("Executive Salary : " + ex.getSalary());
		
	}

	private static void showSalary(Manager m) { //Method Overloading
		// TODO Auto-generated method stub
		System.out.println("Manager Salary :  " + m.getSalary());
		
	}
*/
}
