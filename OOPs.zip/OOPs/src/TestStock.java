

import com.ibm.stock.Broker;
import com.ibm.stock.Exchange;
import com.ibm.stock.Holder;
import com.ibm.stock.Stock;
import com.ibm.stock.StockSingleton;

import static com.ibm.stock.StockSingleton.*;

public class TestStock {
	
	public static void main(String[] args) {
		Stock ibm = new Stock();
		
		Holder h = ibm;
		h.view();
	//	h.get();	//not accessible
	//	h.set();	//not accessible
		
		Broker b = ibm;
		b.view();
		b.get();
	//	b.set();	//not accessible
		
		Exchange e = ibm;
		e.get();
		e.view();
		e.set();
		
		Holder h1 = StockSingleton.getStock(); //without importing statically
		Broker b1  = StockSingleton.getStock(); //without importing statically
		
		Holder h2 = getStock();	// with static import
		Broker b2  = getStock();	//with static import
		
		System.out.println(h1 == b1);
		System.out.println(h == b);
		System.out.println(h2 == b2);
		
		
		
	
	}

}
