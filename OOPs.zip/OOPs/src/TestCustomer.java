

import com.ibm.cust.Customer;
import com.ibm.cust.LoyalCustomers;

public class TestCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Customer c1 = new Customer();
		c1.print();
		
		Customer c2 = new Customer("Arya", 10000);
		c2.print();
		
		LoyalCustomers lc1 = new LoyalCustomers("Ninu", 70000, 10);
		lc1.print();

	}
;
}
