

import com.ibm.library.Book;
import com.ibm.library.LibraryException;
import com.ibm.library.Member;

public class TestLibrary {
	
	public static void main(String[] args) {
		
		Book bk = new Book(1234, "2 States");
		Member m = new Member(1001,"Arya");
		Book bk1 = new Book(5678, "Half Girlfriend");
		Member m1 = new Member(2002,"Ammu");
		
		m.status();
		
		try {
			bk.issueBook(m);
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
			System.out.println(e1);
		}
		
//		bk.status();
		m.status();
		
		try {
			bk.issueBook(m1);
		} catch (LibraryException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//System.out.println(e);
			System.out.println(e.getMessage());
		}
		
/*		bk1.issueBook(m);
		
		bk1.issueBook(m1);
		
		bk1.returnBook(m);
		
		bk1.returnBook(m1);
		
		bk.returnBook(m1);
 		
		bk.returnBook(m);

		bk.status();
		m.status();
		bk1.status();
		m1.status();
*/		
		
	}

}
