package com.ibm.utt;

public class SubscriptionException extends Exception {

	public SubscriptionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SubscriptionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
