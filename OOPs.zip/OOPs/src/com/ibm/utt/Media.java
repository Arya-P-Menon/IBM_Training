package com.ibm.utt;

public abstract class Media {
	
	protected String title;
	private String genre;
	private boolean free;
	
	public Media() {
		// TODO Auto-generated constructor stub
	}

	public Media(String title, String genre, boolean free) {
		super();
		this.title = title;
		this.genre = genre;
		this.free = free;
	}
	
	public void play(User user) throws SubscriptionException {
		if(!free && user.getSubcription()==null)
			throw new SubscriptionException("You are not subscribed to watch " + title);
		else if(genre.equals("Erotic") && user.getAge() <18 || 
				genre.equals("Horror") && user.getAge() > 50) {
			throw new SubscriptionException("You are not eligible to watch "+ genre + " media.");
		}
	}

}
