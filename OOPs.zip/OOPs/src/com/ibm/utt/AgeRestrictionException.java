package com.ibm.utt;

public class AgeRestrictionException extends Exception {

	public AgeRestrictionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AgeRestrictionException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
