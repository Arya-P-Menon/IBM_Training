package com.ibm.utt;

public class Movie extends Media{
	public Movie() {
		// TODO Auto-generated constructor stub
	}

	public Movie(String title, String genre, boolean free) {
		super(title, genre, free);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void play(User user) throws SubscriptionException {
		super.play(user);
		System.out.println("Playing movie " + title);
	}
}
