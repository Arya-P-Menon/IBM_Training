package com.ibm.utt;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Subscription {
	
	//private User user;
	
	private String plan;
	private LocalDate expiry;
	
	private static final double MONTHLY=100;
	private static final double ANNUALLY = 1000;
	
	public Subscription() {
		// TODO Auto-generated constructor stub
	}

	public Subscription(String plan, LocalDate expiry) {
		this.plan = plan;
		this.expiry = expiry;
	}


	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public LocalDate getExpiry() {
		return expiry;
	}

	public void setExpiry(LocalDate expiry) {
		this.expiry = expiry;
	}
	
	public void subscribe(User user,String plan) throws SubscriptionException {

		if(plan.equalsIgnoreCase("Monthly") && user.getBalance() >= MONTHLY) {
			user.setBalance(user.getBalance()-MONTHLY);
			this.plan=plan;
			user.setSubcription(this);
			expiry = LocalDate.now().plus(1, ChronoUnit.MONTHS);
		}
		else if(plan.equalsIgnoreCase("Annually") && user.getBalance() >= ANNUALLY) {
			user.setBalance(user.getBalance()-ANNUALLY);
			this.plan=plan;
			user.setSubcription(this);
			expiry = LocalDate.now().plus(1, ChronoUnit.YEARS);
		}
		else
			throw new SubscriptionException("Insufficient Balance");
			
	}
	

}
