package com.ibm.utt;

public class Series extends Media{
	
	private int seasons;
	private int episodes;
	
	public Series() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Series(String title, String genre, boolean free, int seasons, int episodes) {
		super(title, genre, free);
		this.seasons = seasons;
		this.episodes = episodes;
	}



	@Override
	public void play(User user) throws SubscriptionException {
		super.play(user);
		if(seasons<=this.seasons && episodes<=this.episodes)
			System.out.println("Playing Episode " + episodes+ " of Season " +seasons);
		else
			System.out.println("Cannot play requested media");
	}

}
