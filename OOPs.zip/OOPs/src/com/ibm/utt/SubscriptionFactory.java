package com.ibm.utt;

public final class SubscriptionFactory {

	public SubscriptionFactory() {
		// TODO Auto-generated constructor stub
	}
	
	public static Subscription monthlySubscription() {
		return new Subscription();
	}
	
	public static Subscription annuallySubscription() {
		return new Subscription();
	}
		
}
