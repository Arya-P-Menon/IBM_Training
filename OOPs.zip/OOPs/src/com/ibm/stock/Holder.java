package com.ibm.stock;

public interface Holder {
	void view();

}
