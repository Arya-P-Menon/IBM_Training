package com.ibm.stock;

public final class StockSingleton {
	
	private StockSingleton() {
		// TODO Auto-generated constructor stub
	}
	
	private static Stock s;
	
	//private static Stock s = new Stock(); //will create object s even if not needed so this method is not recommended
	//static final Stock s = new Stock();	// this can be called even without function thus not recommended
	public static Stock getStock() {
		if(s == null)
			s = new Stock();
		
		return s;
		
	}
}
