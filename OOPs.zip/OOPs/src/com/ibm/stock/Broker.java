package com.ibm.stock;

public interface Broker extends Holder {
	void get();
}
