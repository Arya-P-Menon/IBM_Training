package com.ibm.stock;

public interface Exchange extends Broker {
	void set();

}
