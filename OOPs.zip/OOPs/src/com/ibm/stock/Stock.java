package com.ibm.stock;

public class Stock implements Exchange {

	@Override
	public void get() {
		// TODO Auto-generated method stub
		System.out.println("Get");

	}

	@Override
	public void view() {
		// TODO Auto-generated method stub
		System.out.println("View");
		
	}

	@Override
	public void set() {
		// TODO Auto-generated method stub
		System.out.println("Set");

	}

}
