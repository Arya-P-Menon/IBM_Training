package com.ibm.alfa;

public class Alfa {
	
	public Alfa() {
		// TODO Auto-generated constructor stub
		System.out.println("Alfa Constructor");
	}
	
	public void demo() {
		System.out.println("Alfa Demo");
	}

}
