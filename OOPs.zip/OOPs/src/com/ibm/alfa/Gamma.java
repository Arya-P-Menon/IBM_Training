package com.ibm.alfa;

public class Gamma extends Alfa {
	
	public Gamma() {
		// TODO Auto-generated constructor stub
		System.out.println("Gamma Constructor");
	}
	
	public void test() {
		System.out.println("Gamma Test");
	}
	
	public void demo() {
		System.out.println("Gamma Demo");
	}

}
