package com.ibm.alfa;

public class Beta extends Alfa {
	
	public Beta() {
		// TODO Auto-generated constructor stub
		System.out.println("Beta Constructor");
	}
	
	public void test() {
		System.out.println("Beta Test");
	}
}
