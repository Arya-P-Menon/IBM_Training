package com.ibm.bank;

import java.util.Vector;

/**
 * This class represents generalized banking account
 * @author Arya P Menon
 * @version 1.0
 */

public abstract class Account implements Banking {
	
	protected int acntNo;
	protected String holder;
	protected double balance;
	
	//Application Constants
	public static final int INIT_ACC_NO = 1000;
	public static final double MIN_SAV_BAL = 1000;
	public static final double MIN_CUR_BAL = 0;
	public static final double OD_LIMIT = 10000;
	public static final double INIT_CUR_BAL = 5000;
	
	private static int autogen;
	
	//protected Transaction[] txns;
	protected Vector<Transaction> txns = new Vector<Transaction>();
	//protected int idx;
	
	
	static {
		System.out.println("Account class is ready...");
		autogen = INIT_ACC_NO;
	}
	
	/*This is defaut constructor*/
	public Account() {
		// TODO Auto-generated constructor stub
		this("Anonymous",-1);
	}
	
	/**This is parameterised constructor*/
	public Account(String holder, double balance) {
		this.acntNo = autogen++;
		this.holder = holder;
		this.balance = balance;
		
		/*txns = new Transaction[10];
		txns[idx++] = new Transaction("OB", balance, balance);
		*/
		
		txns.add(new Transaction("OB", balance, balance));
	}
	
	public void summary() {
		System.out.println("AccNo. : " +acntNo+ " Holder : " +holder+ " Balance : " +balance);
	}
	
	public void deposit(double amount) {
		this.balance=this.balance+amount;
		
		//txns[idx++] = new Transaction("CR", amount, balance);
		txns.add(new Transaction("CR", amount, balance));
	}
	
	public abstract void withdraw(double amount) throws BalanceException;
	
	public void statement() {
		System.out.println("Statement for A/C : " + acntNo);
		/*for(int i = 0; i<idx ; i++)
			txns[i].print();
			*/
		for(Transaction t : txns)
			t.print();
	}
	
	/*public void withdraw(double amount) {
		if(this.balance>=amount)
			this.balance=this.balance-amount;
		else
			System.out.println("Insufficient balance");
	}
	*/

}
