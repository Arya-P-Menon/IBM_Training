package com.ibm.bank;

public class SavingsAccount extends Account {

	public SavingsAccount() {
		// TODO Auto-generated constructor stub
	}

	public SavingsAccount(String holder) {
		super(holder, MIN_SAV_BAL);
		// TODO Auto-generated constructor stub
	}


	@Override
	public void withdraw(double amount) throws BalanceException {
		if(this.balance-amount < MIN_SAV_BAL)
			//System.out.println("Insufficient Balance");
			throw new BalanceException("Insufficient Balance");
		else {
			this.balance = this.balance-amount;
			//txns[idx++]=new Transaction("DR", amount, balance);
			txns.add(new Transaction("DR", amount, balance));
			//idx++;
		}
	}

}
