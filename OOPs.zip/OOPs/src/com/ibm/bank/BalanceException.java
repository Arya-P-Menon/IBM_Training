package com.ibm.bank;

public class BalanceException extends Exception {

	
	//Generate constructors from super class(option is in source menu)
	public BalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BalanceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
