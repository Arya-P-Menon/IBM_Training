package com.ibm.bank;

public interface Banking {
	
	void summary();
	void statement();
	
	void deposit(double amount);
	void withdraw(double amount) throws BalanceException; //to change signature->right click on withdraw->refactor->
													    	//change method signature->exception tab->add balanceexception->done

}
