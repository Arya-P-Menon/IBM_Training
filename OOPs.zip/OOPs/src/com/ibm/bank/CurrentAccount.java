package com.ibm.bank;

public class CurrentAccount extends Account {
	
	private double overdraft;

	public CurrentAccount() {
		// TODO Auto-generated constructor stub
	}

	public CurrentAccount(String holder) {
		super(holder, INIT_CUR_BAL);
		// TODO Auto-generated constructor stub
		this.overdraft=10000;
	}

	@Override
	public void summary() {
		// TODO Auto-generated method stub
		System.out.println("AccNo. : " +acntNo+ " Holder : " +holder+ " Balance : " +balance+ " Overdraft : "+overdraft);
	}

	@Override
	public void deposit(double amount) {
		// TODO Auto-generated method stub
		overdraft = overdraft + amount;
		if(overdraft>OD_LIMIT) {
			balance = balance + overdraft - OD_LIMIT;
			overdraft=OD_LIMIT;
		}
	}

	@Override
	public void withdraw(double amount) throws BalanceException {
		// TODO Auto-generated method stub
		if(amount<=(balance+overdraft))
		{
			balance = balance - amount;
			if(balance <MIN_CUR_BAL)
			{
				overdraft += balance;
				balance = MIN_CUR_BAL;
			}
		}
		else
			//System.out.println("Insufficient Balance");
			throw new BalanceException("Insufficient Balance");
			
	}
}
