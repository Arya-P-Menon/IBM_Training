package com.ibm.bank;

public final class AccountFactory {
	
	private AccountFactory() {
		// TODO Auto-generated constructor stub
	}

	public static Banking openSavingAccount(String holder) {
		return new SavingsAccount(holder);
	}
	
	public static Banking openCurrentAccount(String holder) {
		return new CurrentAccount(holder);
	}
}
