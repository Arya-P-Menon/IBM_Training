package com.ibm.shop;

public class Payment {
	
	private String accNo;
	private double balance;
	
	public Payment() {
		// TODO Auto-generated constructor stub
	}

	public Payment(String accNo, double balance) {
		this.accNo = accNo;
		this.balance = balance;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	

}
