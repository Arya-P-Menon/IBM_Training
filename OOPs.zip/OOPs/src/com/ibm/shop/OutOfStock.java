package com.ibm.shop;

public class OutOfStock extends Exception {

	public OutOfStock() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OutOfStock(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
