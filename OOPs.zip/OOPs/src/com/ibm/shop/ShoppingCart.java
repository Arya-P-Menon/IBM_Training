package com.ibm.shop;

import java.util.ArrayList;
import java.util.HashMap;

public class ShoppingCart {

	private double cartTotal;
//	private Product[] items;
	private ArrayList<Product> items = new ArrayList<Product>();
	private int idx;
	
	private static final int CART_CAPACITY = 10;
	
	double d;
	
//	String[][] coupons = {{"HOLI","100"}, {"APRIL","900"}};
	
	HashMap<String, Double> coupons = new HashMap<String, Double>();
	
	
	public ShoppingCart() {
		// TODO Auto-generated constructor stub
//		items = new Product[5];
		idx=0;
		
		 //adding values to hashmap should be inside constructor
		coupons.put("HOLI",100.0);
		coupons.put("APRIL", 900.0);
		
	}
	
	public void addProduct(Product p) throws OutOfStock
	{
		if(p.getStock()<1)
			throw new OutOfStock("Out of Stock");
	/*	else if(idx<items.length)
		{
			items[idx++] = p;
			cartTotal += p.getPrice();
			p.setStock(p.getStock()-1);
		} */
		
		else if(idx<CART_CAPACITY) {
			items.add(p);
			idx++;
			cartTotal += p.getPrice();
			p.setStock(p.getStock()-1);
			
		}
		else
			System.out.println("Cart is full");
	}
	
	public void checkout(Payment pmt, String code) throws OutOfStock, PaymentException
	{
		if(idx==0)
			throw new OutOfStock("Cart is empty");
		
		else
		{	
			//for(String[] s : coupons);
			for(String k : coupons.keySet())
			{
				//if(s[0] == code)
				if(k.equalsIgnoreCase(code))
					{
						 //d = Integer.parseInt(s[1]);
						d = coupons.get(k);
						 System.out.println("Discount : " + d);
					}
					
				}
				
			}
			if(cartTotal>d)
				d= cartTotal - d;
			if(d>pmt.getBalance())
				throw new PaymentException("Insufficient Balance");
			else {
				System.out.println("Items\t:\tCost ");
				/*for(int i = 0; i<idx ; i++)
					//System.out.println(items[i].getName() + "\t:\t" + items[i].getPrice());
				*/
				
				for(Product p : items)
					System.out.println(p.getName() + "\t:\t" + p.getPrice());
				System.out.println("Cart Total is Rs." + cartTotal);
				System.out.println("Total price is Rs." + d);
		
			}
		}
}
