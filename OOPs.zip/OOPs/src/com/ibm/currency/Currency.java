package com.ibm.currency;

public interface Currency {
	double dollarValue();

}
