package com.ibm.currency;

public class USD implements Currency {

	@Override
	public double dollarValue() {
		// TODO Auto-generated method stub
		return 1;
	}

}
