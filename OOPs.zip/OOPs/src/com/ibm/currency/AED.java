package com.ibm.currency;

public class AED implements Currency {

	@Override
	public double dollarValue() {
		// TODO Auto-generated method stub
		return 3.67;
	}

}
