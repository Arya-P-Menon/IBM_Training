package com.ibm.currency;

public class INR implements Currency {

	@Override
	public double dollarValue() {
		// TODO Auto-generated method stub
		return 72.50;
	}

}
