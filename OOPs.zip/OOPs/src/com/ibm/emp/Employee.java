package com.ibm.emp;

public class Employee { //Generalised Class
	
	private int empId;
	private String empName;
	private double salary;
	
	private static int autogen;
	
	static {
		System.out.println("Employee class is ready...");
		autogen = 1000;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
		this("Anonymous",-1.0);
		
	}
	

	public Employee(String empName, double salary) {
		this.empId = autogen++;
		this.empName = empName;
		this.salary = salary;
	}
	
	public void paySlip() {
		System.out.println("EmpID : "+empId+"\tEmpName : "+empName+"\tSalary : "+ salary);
	}


	public double getSalary() {
		return salary;
	}


}
