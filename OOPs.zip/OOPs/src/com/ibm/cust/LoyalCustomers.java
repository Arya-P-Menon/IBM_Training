package com.ibm.cust;


public class LoyalCustomers extends Customer {
	
	private int discount;

	public LoyalCustomers() {
		// TODO Auto-generated constructor stub
	}

	public LoyalCustomers(String custName, double creditLimit, int discount) {
		super(custName, creditLimit);
		// TODO Auto-generated constructor stub
		this.discount=discount;
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
		System.out.println("Discount % : " + discount);
	}

}
