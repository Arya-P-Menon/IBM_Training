package com.ibm.cust;


public class Customer {
	
	private int custId;
	private String custName;
	private double creditLimit;
	
	private static int autogen;
	
	static {
		System.out.println("Customer class is ready...");
		autogen = 1000;
	}
	
	public Customer() {
		// TODO Auto-generated constructor stub
		this("Anonymous",-1);
	}

	public Customer(String custName, double creditLimit) {
		this.custId = autogen++;
		this.custName = custName;
		this.creditLimit = creditLimit;
	}
	
	public void print() {
		System.out.println("ID : "+custId+" Name : "+custName+" Credit Limit : "+creditLimit);
	}

	
}
