package com.ibm.library;

public class LibraryException extends Exception {

	public LibraryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LibraryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
