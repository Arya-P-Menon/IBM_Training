

//import com.ibm.bank.Account;
import com.ibm.bank.Banking;
//import com.ibm.bank.CurrentAccount;
//import com.ibm.bank.SavingsAccount;
import com.ibm.bank.AccountFactory;
import com.ibm.bank.BalanceException;

public class TestAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	/*	Account a1 =new Account();
		a1.summary();
		
		System.out.println("************************************************");
		
		Account a2 = new Account("Arya",50000);
		a2.summary();
		a2.deposit(2000);
		a2.summary();
		a2.withdraw(3000);
		a2.summary();
		a2.withdraw(1000000);
		a2.summary();
		
		*/
		
		System.out.println("************************************************");
		
		/*SavingsAccount s1 = new SavingsAccount("Manu");
		s1.deposit(10);
		s1.withdraw(10);
		s1.summary();
		
		s1.statement();
		
		System.out.println("************************************************");
		
		Account ca = new CurrentAccount("Ammu");
		
		ca.withdraw(3000);
		ca.withdraw(7000);
		ca.deposit(2000);
		ca.deposit(4000);
		ca.summary();
		
		System.out.println("************************************************");
		
		Banking b1 = new SavingsAccount("Manuj");
		b1.deposit(1090);
		b1.withdraw(789);
		b1.summary();
		
		b1.statement();*/
		
		System.out.println("************************************************");
		
		Banking b2 = AccountFactory.openSavingAccount("Ram");
		b2.deposit(1090);
		
		//surround with try catch
		try {
			b2.withdraw(700);
		} catch (BalanceException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();	// for debugging/toubleshooting - User  is developer
//			System.out.println(e);	// for system/application audit - User is loggers
			System.out.println(e.getMessage());		// for end users
		}
		
		b2.summary();
		
		b2.statement();
		

	}

}
