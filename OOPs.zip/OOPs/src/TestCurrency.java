

import com.ibm.currency.AED;
import com.ibm.currency.CurrencyConverter;
import com.ibm.currency.INR;
import com.ibm.currency.USD;

public class TestCurrency {
	public static void main(String[] args) {
		INR inr = new INR();
		USD usd = new USD();
		AED aed = new AED();
		CurrencyConverter cc = new CurrencyConverter();
		
		System.out.println(cc.converter(usd, inr, 5000));
		System.out.println(cc.converter(inr, usd, 5000));
		System.out.println(cc.converter(usd, aed, 5000));
		System.out.println(cc.converter(aed, inr, 5000));
	}
}
