import com.ibm.alfa.Alfa;
import com.ibm.alfa.Beta;
import com.ibm.alfa.Gamma;

public class TestAlfa {
	
	public static void main(String[] args) {
		Alfa a = new Alfa();
		a.demo();
		
		Beta b = new Beta();
		b.demo();
		b.test();
		
		Gamma c = new Gamma();
		c.demo();
		c.test();
		
		Alfa ab = b; // Up-Casting
		ab.demo();
	//	ab.test(); // Error - not accessible
		
		Beta ba = (Beta)ab; // Down - Casting
		ba.test();
		ba.demo();
		
		Alfa ac = c;
		ac.demo();
		
	/*	Beta bt = (Beta) a; // error - a has no access to b.. so down casting not possible
		bt.test();
	*/	
		
		
		
	}

}
