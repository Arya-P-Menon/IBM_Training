
public interface Event {
	void doSomething();

}

class EventImpl implements Event{

	@Override
	public void doSomething() {
		// TODO Auto-generated method stub
		System.out.println("First Task");
		
	}
	
	static class InnerEventImpl implements Event{

		@Override
		public void doSomething() {
			// TODO Auto-generated method stub
			System.out.println("Second Task");
		}
		
	}
	
	public void oneMoreImpl() {
		class NestedEventImpl implements Event{

			@Override
			public void doSomething() {
				// TODO Auto-generated method stub
				System.out.println("Third Task");
				
			}	
		}
		new NestedEventImpl().doSomething();
	}
	
	public void oneLastImpl() {
		Event e = new Event () {

			@Override
			public void doSomething() {	//Anonymous inner class
				// TODO Auto-generated method stub
				System.out.println("Fourth Task");
			}
		};
		e.doSomething();
	}
	
	public void pakkaLastImpl() {
		Event e = () -> System.out.println("Fifth Task");	//Lambda Expression
		e.doSomething();
	}
	
	public static void main(String[] args) {
		EventImpl ei = new EventImpl();
		ei.doSomething();
		
	//	InnerEventImpl inner = ei.new InnerEventImpl(); //non static inner class
		
		
		InnerEventImpl inner = new InnerEventImpl(); // if inner class was static
		//EventImpl.InnerEventImpl inner = new EventImpl.InnerEventImpl();	//	another implementation for static inner class
		
		inner.doSomething();
		
		
		
		//in.doSomething();
		
		ei.oneMoreImpl();
		ei.oneLastImpl();
		ei.pakkaLastImpl();
	}
}
