import com.ibm.utt.Movie;
import com.ibm.utt.Series;
import com.ibm.utt.Subscription;
import com.ibm.utt.SubscriptionException;
import com.ibm.utt.User;

public class TestUtt {
	
	public static void main(String[] args) {
		Subscription sub = new Subscription();
		User u1 = new User("Polo",17,"Male",2000);
		User u2 = new User("Mark",25,"Male",150);
		User u3 = new User("Kim",59,"Female",00);
		
		Movie m1 = new Movie("Ant","Erotic",false);
		Movie m2 = new Movie("Soul","Horror",true);
		Movie m3 = new Movie("DJ","Action",false);
		
		Series s1 = new Series("GoT","Erotic",false,7,10);
		Series s2 = new Series("Lost","Action",false,3,10);
		
		u1.profile();
		try {
			sub.subscribe(u1, "Annually");
		} catch (SubscriptionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		u1.profile();
		
		try {
			m2.play(u1);
		} catch (SubscriptionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			s2.play(u3);
		} catch (SubscriptionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
