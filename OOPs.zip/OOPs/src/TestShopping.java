

import com.ibm.shop.OutOfStock;
import com.ibm.shop.Payment;
import com.ibm.shop.PaymentException;
import com.ibm.shop.Product;
import com.ibm.shop.ShoppingCart;

public class TestShopping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ShoppingCart sc1 = new ShoppingCart();
		Payment pmt = new Payment("12345",5000);
	/*	try {
			sc1.checkout(pmt,"Holi");
		} catch (PaymentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		Product p1 = new Product("Pen", 29,8);
		Product p2 = new Product("Pencil", 10,9);
		Product p3 = new Product("Scale", 25,18);
		Product p4 = new Product("Eraser", 30,80);
		Product p6 = new Product("Pen", 28,90);
		try {
			sc1.addProduct(p1);
		} catch (OutOfStock e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			sc1.addProduct(p2);
		} catch (OutOfStock e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			sc1.addProduct(p3);
		} catch (OutOfStock e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			sc1.addProduct(p4);
		} catch (OutOfStock e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			sc1.addProduct(new Product("Pen",29,99));
		} catch (OutOfStock e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //another method
		try {
			sc1.addProduct(p6);
		} catch (OutOfStock e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

			try {
				sc1.checkout(pmt, "HOLI");
			} catch (OutOfStock | PaymentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	

	}

}
