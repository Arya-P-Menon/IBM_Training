package com.ibm.train.repo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.ibm.train.pojo.Train;

@Repository
public class TrainRepositoryImpl implements TrainRepository {
	
	private Map<Integer, Train> trains;
	
	public TrainRepositoryImpl() {
		trains = new HashMap<Integer, Train>();
		trains.put(1203, new Train(1203,"Raat Rani","Chennai","Nagpur"));
		
	}

	@Override
	public int saveTrain(Train t) {
		// TODO Auto-generated method stub
		trains.put(t.getTcode(), t);
		return t.getTcode();
	}

	@Override
	public Train fetchTrain(int tcode) {
		// TODO Auto-generated method stub
		return trains.get(tcode);
	}

	@Override
	public Collection<Train> fetchAll() {
		// TODO Auto-generated method stub
		return trains.values();
	}

	@Override
	public int delTrain(int tcode) {
		trains.remove(tcode);
		return tcode;
	}

}
