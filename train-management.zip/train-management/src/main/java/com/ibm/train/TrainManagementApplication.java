package com.ibm.train;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainManagementApplication.class, args);
	}

}
