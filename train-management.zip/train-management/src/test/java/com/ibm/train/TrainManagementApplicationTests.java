package com.ibm.train;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
