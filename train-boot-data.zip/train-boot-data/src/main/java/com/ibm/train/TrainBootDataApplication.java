package com.ibm.train;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainBootDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainBootDataApplication.class, args);
	}

}
