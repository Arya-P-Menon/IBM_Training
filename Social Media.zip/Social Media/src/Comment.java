
public class Comment {

	private User user;
	private String message;
	
	public Comment() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Comment(User user, String message) {
		this.user = user;
		this.message = message;
	}



	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return user.getName() + " : " + message;
	}

	
}
