
public class Dashboard {
	
	private Post posts[];
	
	public Dashboard() {
		// TODO Auto-generated constructor stub
	}
	

	public Dashboard(Post...posts) {
		this.posts = posts;
	}



	public Post[] getPosts() {
		return posts;
	}

	public void setPosts(Post...posts) {
		this.posts = posts;
	}
	
	
	public void Dash() {
		for(Post p : this.posts) {
			p.viewPost();
			System.out.println("------------------");
		}
	}

}
