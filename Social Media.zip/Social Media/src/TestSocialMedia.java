import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class TestSocialMedia {

	public static void main(String[] args) {
	
	User u1 = new User("Arya");
	User u2 = new User("Vishnu");
	User u3 = new User("Meena");
	User u4 = new User("Pradeep");
	
	Comment c1 = new Comment(u2,"Nice");
	Comment c2 = new Comment(u3,"Superb");
	Comment c3 = new Comment(u4, "Good");
	
	Post p1 = new Post(u1, "Education", LocalDate.now(), 78, 12, c1,c2,c3);
	Post p2 = new Post(u2, "Game", LocalDate.now().plus(3, ChronoUnit.DAYS), 100, 0, c3,c2,c1);
	
	Dashboard d1 = new Dashboard(p1,p2);
	
	d1.Dash();

	}
	
	
	
}
