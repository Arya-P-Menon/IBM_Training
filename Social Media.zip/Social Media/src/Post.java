import java.time.LocalDate;

public class Post {
	
	private User user;
	private String content;
	private LocalDate postDate;
	private int likes;
	private int dislikes;
	private Comment comments[];
	
	public Post() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Post(User user, String content, LocalDate postDate, int likes, int dislikes, Comment...comments) {
		this.user = user;
		this.content = content;
		this.postDate = postDate;
		this.likes = likes;
		this.dislikes = dislikes;
		this.comments = comments;
	}



	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public LocalDate getPostDate() {
		return postDate;
	}
	public void setPostDate(LocalDate postDate) {
		this.postDate = postDate;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public int getDislikes() {
		return dislikes;
	}
	public void setDislikes(int dislikes) {
		this.dislikes = dislikes;
	}
	public Comment[] getComments() {
		return comments;
	}
	public void setComments(Comment...comments) {
		this.comments = comments;
	}
	
	public void viewPost() {
		System.out.println("User : "+this.getUser().getName());
		System.out.println("Content : "+this.getContent());
		System.out.println("Post Date : "+this.getPostDate());
		System.out.println("Count of likes : "+this.getLikes());
		System.out.println("Count of dislikes : "+this.getDislikes());
		System.out.println("***Comments***");
		for(Comment c : comments) {
			System.out.println(c.toString());
		}
	}
	

}
