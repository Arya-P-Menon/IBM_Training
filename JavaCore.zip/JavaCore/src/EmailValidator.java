public class EmailValidator {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String email = "zubair@mail.com";
		int iat = email.indexOf('@');
		int jat = email.indexOf('.');
		if( iat > 3 && jat >8 && email.lastIndexOf('@') == iat 
				&& email.lastIndexOf('.') == jat && email.length() > jat+2 )
			System.out.println("Valid mail");
		else
			System.out.println("Invalid mail");
		
	}

}
