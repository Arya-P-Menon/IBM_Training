
public class RomanNumerals {
	
	private static final int[] decimalNo = {1000,900,500,400,100,90,50,40,10,9,5,4,1};
	private static final String[] romanNo = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
	
	public static final void convert(int num) {
		
		for(int i = 0; i<decimalNo.length; i++) {
			while(num>=decimalNo[i]) {
				num -= decimalNo[i];
				System.out.print(romanNo[i]);
			}
		}
	}
	
	public static void main(String[] args) {
		
		convert(50056);
	}

}
