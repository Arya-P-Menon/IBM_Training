package com.ibm.dao;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.ibm.entity.Department;
import com.ibm.entity.Movie;
import com.ibm.entity.Multiplex;

public class MovieDao {
	
	private EntityManagerFactory factory;
	
	public MovieDao() {
		factory = Persistence.createEntityManagerFactory("MyJPA");
	}
	
	public int addMultiplex(Multiplex m) {
		EntityManager em = factory.createEntityManager();
		EntityTransaction txn = em.getTransaction();
		txn.begin();
		em.persist(m);
		txn.commit();
		em.close();
		return m.getMpexId();
		
	}
	
	public int addMovie(Movie m) {
		
		EntityManager em = factory.createEntityManager();
		EntityTransaction txn = em.getTransaction();
		txn.begin();
		em.persist(m);
		txn.commit();
		em.close();
		return m.getMovieId();
		
	}
	
	public boolean addMovieToMultiplex(int movId, int mpexId) {
		
		EntityManager em = null;
		EntityTransaction  txn = null;
		try {
			em = factory.createEntityManager();
			txn = em.getTransaction();
			txn.begin();
			Movie mov = em.find(Movie.class, movId);
			Multiplex mpex = em.find(Multiplex.class, mpexId);
			Set<Multiplex> mpexs = mov.getMultiplexs();
			mpexs.add(mpex);
	//		Set<Movie> movs = mpex.getMovies();//one addition is enough , other 
	//                                   get automatically added as inverse column is provided in join column condition
	//		movs.add(mov);
			em.merge(mov);
			em.merge(mpex);
			txn.commit();
			return true;
		} catch (Exception e) {
			txn.rollback();
			e.printStackTrace();
			return false;
		}finally {
		em.close();
		}
	}
	
	public Multiplex findMultiplex(int mpexId) {
		EntityManager em = null;
		try {
			em = factory.createEntityManager();
			Multiplex m = em.find(Multiplex.class, mpexId);
			return m;
		}finally {
			em.close();
		}
	}
	
	public Movie findMovie(int movId) {
		EntityManager em = null;
		try {
			em = factory.createEntityManager();
			Movie m = em.find(Movie.class, movId);
			return m;
		}finally {
			em.close();
		}
	}

}
