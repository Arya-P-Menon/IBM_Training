package com.ibm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "music_album")
public class Album {
	@TableGenerator(name = "music", initialValue = 0)
	  @Id
	  @GeneratedValue(strategy = GenerationType.TABLE, generator = "music")
	
	//@Id
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "init")
	@Column(name = "album_id")
	private int albumId;
	
	@Column(length = 20)
	private String title;
	
	@Column(length = 10)
	private String genre;
	private double rating;
	
	
	public int getAlbumId() {
		return albumId;
	}
	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	
	
	@Override
	public String toString() {
		return "Album [albumId=" + albumId + ", title=" + title + ", genre=" + genre + ", rating=" + rating + "]";
	}
	
	
	
	

}
