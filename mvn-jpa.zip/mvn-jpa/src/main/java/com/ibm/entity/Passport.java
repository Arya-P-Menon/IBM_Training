package com.ibm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Passport implements Serializable {
	
	@Column(length = 15)
	private String country;
	@Column(name = "passport_no")
	private int number;
	
	public Passport() {
		// TODO Auto-generated constructor stub
	}

	public Passport(String country, int number) {
		super();
		this.country = country;
		this.number = number;
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

	@Override
	public String toString() {
		return super.toString();
	}
	
	

}
