package com.ibm.test;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.ibm.dao.MovieDao;
import com.ibm.entity.Department;
import com.ibm.entity.Employee;
import com.ibm.entity.Movie;
import com.ibm.entity.Multiplex;

public class TestMovieDao {

private static MovieDao dao;

	
	@BeforeAll
	public static void setup() {
		dao = new MovieDao();

	}
	
	@Test
	public void testAddMultiplex() {
		Multiplex m = new Multiplex();
		m.setName("Dreams");
		m.setCity("PKD");
		assertNotEquals(0, dao.addMultiplex(m));
		System.out.println(m.getMpexId());
	}
	
	@Test
	public void testAddMovie() {
		Movie m = new Movie();
		m.setTitle("AD");
		m.setRating(4.0);
		assertNotEquals(0, dao.addMovie(m));
		System.out.println(m.getMovieId());
	}
	
	@Test
	public void testAddMovieToMultiplex() {
		assertTrue(dao.addMovieToMultiplex(1, 1000));
	}
	
	@Test
	public void testFindMultiplex() {
		
		Multiplex m = dao.findMultiplex(1000);
		assertNotNull(m);
		System.out.println(m);
		m.getMovies().forEach(System.out::println);
	}
	
	@Test
	public void testFindMovie() {
		
		Movie m = dao.findMovie(1);
		assertNotNull(m);
		System.out.println(m);
		m.getMultiplexs().forEach(System.out::println);
	}
	
	
	

}
