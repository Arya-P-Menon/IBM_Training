package com.ibm.test;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.ibm.dao.EmpDeptDao;
import com.ibm.entity.Department;
import com.ibm.entity.Employee;

public class TestEmpDept {
	
	private static EmpDeptDao dao;

	
	@BeforeAll
	public static void setup() {
		dao = new EmpDeptDao();

	}
	
	@Test
	public void testDeptAdd() {
		Department d = new Department();
		d.setDeptId(30);
		d.setDeptName("AI");
		assertNotEquals(0, dao.addDept(d));
		System.out.println(d);
	}
	
	
	@Test
	public void testEmpAdd() {
		Employee e = new Employee();
		e.setEmpName("Arya ");
		e.setSalary(50000);

		assertNotEquals(0, dao.addEmp(e, 30));	
		System.out.println(e);
	}
	
	@Test
	public void testFindDept() {
		
		Department d = dao.findDept(30);
		assertNotNull(d);
		System.out.println(d);
		d.getEmps().forEach(System.out::println);
	}
	
	@Test
	public void testRemoveDept() {
		assertTrue(dao.removeDept(30));
	}
	
}
