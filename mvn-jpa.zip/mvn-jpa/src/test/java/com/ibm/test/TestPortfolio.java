package com.ibm.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.ibm.dao.PortfolioDao;
import com.ibm.entity.Portfolio;

public class TestPortfolio {
	
	private static PortfolioDao dao;

	
	@BeforeAll
	public static void setup() {
		dao = new PortfolioDao();

	}
	
	@Test
	public void testAddPortfolio() {
		Portfolio p = new Portfolio();

		assertEquals(21, dao.addPortfolio(21));
		System.out.println(p);
	}
	
	
	@Test
	public void testFindDept() {
		
		Portfolio p = dao.getPortfolio(21);
		assertNotNull(p);
		System.out.println(p);
		p.getShares().forEach(System.out::println);
	}
	
	

}
