package com.ibm;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestAccount {
	private Account acnt;
	
	@BeforeEach
	public void init() {
		acnt = new Account(1000);
	}
	
	@Test
	public void testWithdraw() throws BalanceException {
		assertEquals(500, acnt.withdraw(500));
	}
	
	@Test
	public void testInvalidWithdraw() {
		assertThrows(BalanceException.class, ()-> acnt.withdraw(1500));
	}
	
	@Test
	public void testNegativeWithdraw() throws BalanceException{
		assertThrows(NumberFormatException.class, () ->acnt.withdraw(-200));
	}
	
	@Test
	public void testDeposit() {
		assertEquals(1500, acnt.deposit(500));
	}
	
	@Test
	public void testNegativeDeposit() {
		assertThrows(NumberFormatException.class, ()->acnt.deposit(-90));
	}
	
	@Test
	public void wrongDepositTest() {
		assertNotEquals(2000, acnt.deposit(200));
	}

}
