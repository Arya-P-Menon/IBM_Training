package com.ibm.mongo.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ibm.mongo.model.Astronaut;

public interface AstronautRepository extends MongoRepository<Astronaut, Integer>{

}
