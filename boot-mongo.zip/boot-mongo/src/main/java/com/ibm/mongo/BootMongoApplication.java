package com.ibm.mongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMongoApplication.class, args);
	}

}
