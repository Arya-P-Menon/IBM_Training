import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;

public class DequeueDemo {
	
	public static void main(String[] args) {
		
		Deque<Integer> dq = new LinkedList<Integer>();
		dq.add(12);
		dq.add(50);
		dq.add(67);
		dq.add(100);
		dq.add(50);
		
		System.out.println("Deque is : " + dq);
		
		dq.removeFirstOccurrence(50);
		System.out.println("Deque is : " + dq);
		
		dq.removeFirst();
		System.out.println("Deque is : " + dq);
		
		dq.removeLast();
		System.out.println("Deque is : " + dq);
		
		System.out.println("Peek is : " + dq.peek());
		
		while(!dq.isEmpty()) {
			System.out.println("Poll is : " + dq.poll());
			System.out.println("Queue is : " + dq);
		}
		
	}
}
