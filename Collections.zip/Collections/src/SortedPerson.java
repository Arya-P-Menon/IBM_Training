import java.util.Comparator;
import java.util.TreeSet;

public class SortedPerson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonAgeComparator pac = new PersonAgeComparator();
		
		Comparator<Person> pnc = (p1,p2) -> p1.getName().compareTo(p2.getName());
		
		PersonComparator pc = new PersonComparator();

		
		
	//	TreeSet<Person> persons = new TreeSet<Person>(pac);	//pac used for sorting else classcast exception occurs
	//	TreeSet<Person> persons = new TreeSet<Person>(pnc);
		
		TreeSet<Person> persons = new TreeSet<Person>(pc);
		persons.add(new Person("Polo",12));
		persons.add(new Person("Mili",12));
		persons.add(new Person("Mili",17));
		
		for(Person p : persons)
			System.out.println(p);
	}

}



class PersonAgeComparator implements Comparator<Person>{

	@Override
	public int compare(Person p1, Person p2) {
		// TODO Auto-generated method stub
		return p1.getAge() - p2.getAge();	//if +ve p1 is greater, -ve means p2 is greater, if 0 then same,thus ignores as Set doesn't allow duplicates
	}
	
}

class PersonComparator implements Comparator<Person>{

	@Override
	public int compare(Person p1, Person p2) {
		// TODO Auto-generated method stub
		int name = p1.getName().compareTo(p2.getName());
		int age = p1.getAge()-p2.getAge();
		if(name == 0)
			return age;
		return name;
	}
	
}