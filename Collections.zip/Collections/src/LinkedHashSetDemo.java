import java.util.LinkedHashSet;

public class LinkedHashSetDemo {
	

	public static void main(String[] args) {
		LinkedHashSet<String> set = new LinkedHashSet<String>();
		set.add("Apple");
		set.add("Google");
		set.add("Oracle");
		set.add("Microsoft");
		set.add("IBM");
		
		System.out.println(set);
		
		set.remove("Oracle");
		System.out.println(set);
	}

}

