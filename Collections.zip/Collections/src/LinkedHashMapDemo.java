import java.util.HashMap;
import java.util.LinkedHashMap;

public class LinkedHashMapDemo {
	public static void main(String[] args) {
		
		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
		map.put("jack", "jill");
		map.put("scott", "tiger");
		map.put("polo","lilli");
		map.put("jack","rose");	// change jill to rose
		
		System.out.println(map.get("polo"));
		System.out.println(map.get("scott"));
		System.out.println(map.get("polo"));
		
		System.out.println(map.entrySet());
		
		for(String key : map.keySet())
			System.out.println(key + " : " + map.get(key));
	}

}
