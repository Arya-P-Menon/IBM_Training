import java.util.HashMap;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("jack", "jill");
		map.put("scott", "tiger");
		map.put("polo","lilli");
		map.put("jack","rose");	// change jill to rose
		
		System.out.println(map.get("jack"));
		System.out.println(map.get("scott"));
		System.out.println(map.get("polo"));
		
		System.out.println(map.entrySet());
		
		for(String key : map.keySet())
			System.out.println(key + " : " + map.get(key));
	}

}
