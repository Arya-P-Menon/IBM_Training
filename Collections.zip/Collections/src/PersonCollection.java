import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

public class PersonCollection {
	
	public static void main(String[] args) {
		Vector<Person> persons = new Vector<Person>();
		persons.add(new Person("Polo",12));
		persons.add(new Person("Lili",21));
		persons.add(new Person("Mili",17));
		
		for(Person p : persons)
			System.out.println(p);
		
		Hashtable<Integer, Person> people = new Hashtable<Integer, Person>();
		people.put(1, new Person("Polo",12));
		people.put(2, new Person("Lili",21));
		people.put(3, new Person("Mili",17));
		
		for(int key : people.keySet())
			System.out.println(key + " : " + people.get(key));
		
		for(int k=1; k<=3; k++)
			System.out.println(k + " : " + people.get(k));

		
	}

}
