import java.util.Locale;
import java.util.ResourceBundle;

public class LocalDemo {
	public static void main(String[] args) {
		
	//	Locale french = Locale.FRENCH;
	//	ResourceBundle bundle = ResourceBundle.getBundle("msgs",french);
		
		Locale malayalam = new Locale("mal");
		ResourceBundle bundle = ResourceBundle.getBundle("msgs",malayalam);
		
		//ResourceBundle bundle = ResourceBundle.getBundle("msgs");	// by default it takes english
		
		System.out.println(bundle.getString("greeting"));
		System.out.println(bundle.getString("message"));
	}
}
