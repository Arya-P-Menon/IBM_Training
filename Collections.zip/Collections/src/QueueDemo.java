import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {
	
	public static void main(String[] args) {
		
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(8);
		q.add(3);
		q.add(5);
		q.add(10);
		System.out.println("Queue is : " + q);
		
		q.remove();
		System.out.println("Queue is : " + q);
		
		System.out.println("Head is : " + q.peek());
		while(!q.isEmpty()) {
			System.out.println("Poll is : " + q.poll());
			System.out.println("Queue is : " + q);
		}
		
	}

}
