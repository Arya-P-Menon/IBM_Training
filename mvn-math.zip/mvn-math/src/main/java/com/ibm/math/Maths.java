package com.ibm.math;

public class Maths {
	
	public int sum(int a, int b) {
		return a+b;
	}
	
	public int sub(int a , int b) {
		return a-b;
	}
	
	public int div(int a, int b) {
		return a/b;
	}
	
	public int square(int a) {
		return a*a;
	}

}
