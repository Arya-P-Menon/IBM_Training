package com.ibm.pizza;

public class ToppingsException extends Exception {

	public ToppingsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ToppingsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
