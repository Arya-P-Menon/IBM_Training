package com.ibm.pizza;

public class Pizza {
	
	public Pizza() {
		// TODO Auto-generated constructor stub
	}
	
	public double order(String size, int toppings) throws InvalidSizeException, ToppingsException {
		int cost=0;
		
		if(size.equalsIgnoreCase("s"))
			cost +=100;
		else if(size.equalsIgnoreCase("m"))
			cost +=200;
		else if(size.equalsIgnoreCase("l"))
			cost +=300;
		else
			throw new InvalidSizeException();
		if(toppings>1 && toppings <6)
			cost += 50*toppings;
		else 
			throw new ToppingsException();
		
		return cost;
			
	}

}
