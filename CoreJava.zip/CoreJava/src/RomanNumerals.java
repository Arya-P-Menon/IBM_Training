
public class RomanNumerals {
	
	private static final int[] DECIMAL_NO = {1000,900,500,400,100,90,50,40,10,9,5,4,1};
	private static final String[] ROMAN_NO = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
	
	public static final void convert(int num) {
		
		for(int i = 0; i<DECIMAL_NO.length; i++) {
			while(num>=DECIMAL_NO[i]) {
				num -= DECIMAL_NO[i];
				System.out.print(ROMAN_NO[i]);
			}
		}
	}
	
	public static void main(String[] args) {
		
		convert(5056);
	}

}
