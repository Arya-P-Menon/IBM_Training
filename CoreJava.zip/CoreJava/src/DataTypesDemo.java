
public class DataTypesDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 876;
		float f = 3.12F;
		double d = 0.987654321;
		long l = 9876543210L;
		char c = 'A';
		boolean b = true;
		
		System.out.println("Int : "+ i);
		System.out.println("Float : "+ f);
		System.out.println("Double : "+ d);
		System.out.println("Long : "+ l);
		System.out.println("Char : "+ c);
		System.out.println("Boolean : "+ b);
		System.out.println("Boolean : "+ !b);
		
	}

}
