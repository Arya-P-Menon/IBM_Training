
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestPizza {
	
	private Pizza p;
	
	@BeforeEach
	public void setup() {
		p = new Pizza();
	}
	
	@Test
	public void small2Order() throws InvalidSizeException, ToppingsException {
		assertEquals(200, p.order("s", 2));
	}
	
	@Test
	public void small3Order() throws InvalidSizeException, ToppingsException {
		assertEquals(250, p.order("s", 3));
	}
	
	@Test
	public void small4Order() throws InvalidSizeException, ToppingsException {
		assertEquals(300, p.order("s", 4));
	}
	
	@Test
	public void small5Order() throws InvalidSizeException, ToppingsException {
		assertEquals(350, p.order("s", 5));
	}
	
	@Test
	public void medium2Order() throws InvalidSizeException, ToppingsException {
		assertEquals(300, p.order("m", 2));
	}
	
	@Test
	public void medium3Order() throws InvalidSizeException, ToppingsException {
		assertEquals(350, p.order("m", 3));
	}
	
	@Test
	public void medium4Order() throws InvalidSizeException, ToppingsException {
		assertEquals(400, p.order("m", 4));
	}
	
	@Test
	public void medium5Order() throws InvalidSizeException, ToppingsException {
		assertEquals(450, p.order("m", 5));
	}
	
	@Test
	public void large2Order() throws InvalidSizeException, ToppingsException {
		assertEquals(400, p.order("l", 2));
	}
	
	@Test
	public void large3Order() throws InvalidSizeException, ToppingsException {
		assertEquals(450, p.order("l", 3));
	}
	
	@Test
	public void large4Order() throws InvalidSizeException, ToppingsException {
		assertEquals(500, p.order("l", 4));
	}
	
	@Test
	public void large5Order() throws InvalidSizeException, ToppingsException {
		assertEquals(550, p.order("l", 5));
	}
	
	@Test
	public void invalidSizeOrder() {
		assertThrows(InvalidSizeException.class,()-> p.order("p", 4));
	}
	
	@Test
	public void invalidToppingsOrder() {
		assertThrows(ToppingsException.class,()-> p.order("l", 0));
	}

}
