import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class TestSubscription {
	
	private static Subscription sub;

	@BeforeAll//zubair used beforeEach
	public static void init() {
		sub = new Subscription();
	}
	
	@Test
	public void testMonthly() {
		assertEquals(100, sub.monthly());
	}
	
	@Test
	public void testQuarterly() {
		assertEquals(250, sub.quarterly());
	}
	
	@Test
	public void testAnnually() {
		assertEquals(1000, sub.annually());
	}
	
}
