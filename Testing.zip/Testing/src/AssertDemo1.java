
public class AssertDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = 20;
		
		assert age > 18 : "Not Valid";//print msg if condition is false
		
		System.out.println("Age : " + age);

	}

}
