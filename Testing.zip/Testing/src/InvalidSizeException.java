
public class InvalidSizeException extends Exception {

	public InvalidSizeException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidSizeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
