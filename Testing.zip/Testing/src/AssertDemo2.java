
public class AssertDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		assert args.length == 3 : "Mandatory to print 3 arguments";
		
		for(String a : args)
			System.out.println(a);

	}

}
