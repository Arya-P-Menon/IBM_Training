
public class Subscription {
	
	public double monthly() {
		return 100;
	}
	
	public double quarterly() {
		return 250;
	}
	
	public double annually() {
		return 1000;
	}
	

}
