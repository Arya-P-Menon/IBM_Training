import static org.junit.jupiter.api.Assertions.assertTimeout;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

public class TestTimeout {
	
	@Test
	@Timeout(unit = TimeUnit.MILLISECONDS, value = 100)// if time takes more than 100ms test fails
	public void testTimeout() throws InterruptedException {
		Thread.sleep(9);
//		assertTimeout(Duration.ofMillis(10),()-> {while(true);});
		
	}
	
	@Test
	public void testTimeoutAssert() {
//		assertTimeout(Duration.ofMillis(100), TestTimeout::abc);
		assertTimeout(Duration.ofMillis(100),()-> {Thread.sleep(9);});// if time takes more than 100ms test fails
															// abc() 's lambda implementation
		
	}
	
	public static void abc() {
		
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
