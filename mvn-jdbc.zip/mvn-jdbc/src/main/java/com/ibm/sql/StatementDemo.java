package com.ibm.sql;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class StatementDemo {
	public static void main(String[] args) {
		String sql = "insert into emp values (1007,'Polo',55000)";
		Connection conn = null;

		try {
			conn = JdbcUtil.getConnection();
			Statement stmt = conn.createStatement();
			int rec = stmt.executeUpdate(sql);
			System.out.println(rec + " Record inserted");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}