package com.ibm.sql;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestJdbc {
	

	
	@Test
	public void connectionTest() throws SQLException {
		assertNotNull(JdbcUtil.getConnection());
	}

}
