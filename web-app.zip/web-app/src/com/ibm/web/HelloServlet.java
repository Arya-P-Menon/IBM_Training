package com.ibm.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private int counter = 10;
       
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
    	resp.setContentType("text/html");
    	
    	out.println("<h1>Hello</h1>");
    	out.println("<h2>Welcome</h2>");
    	counter++;
    	out.println("<h3>Visitor number : "+counter+"</h3>");
    	
    	Date now = new Date();
    	out.println("<h3>Log : "+now+"</h3>");
	}

}
